# godot4-mediapipe

web demo on itch https://luklev.itch.io/godot4-mediapipe, (after clicking "run game", the content is loading 20-30 sec), allow it to use webcam so it can detect the pos :)

Godot4 web vtuber concept using pose and face recognition with mediapipe

web view
![image](https://github.com/TechnoLukas/Godot4-mediapipe/assets/110934679/205723df-527f-4f24-be4e-059b7f89d28d)

mediapipe js based on https://github.com/LintangWisesa/MediaPipe-in-JavaScript


**TODO:**
- 3d lines
- show browser difference
- visualize html file evolution and callbacks
